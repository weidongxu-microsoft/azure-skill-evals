# @microsoft/vally

Core library for [Vally](https://aka.ms/vally) — the evaluation platform built for builders.

This package provides the discovery, grader, executor, trajectory, scoring, and reporting primitives that power Vally. It is consumed by [`@microsoft/vally-cli`](https://www.npmjs.com/package/@microsoft/vally-cli) and can be embedded in custom tooling (CI actions, IDE integrations, hosted services).

For end-user documentation, visit [https://aka.ms/vally](https://aka.ms/vally).

## Installation

```bash
npm install @microsoft/vally
```

Requires Node.js `>=22`.

## License

MIT — see [LICENSE](./LICENSE). Copyright (c) Microsoft Corporation.
